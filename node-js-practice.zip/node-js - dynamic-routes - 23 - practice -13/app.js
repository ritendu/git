const express = require('express');
const app = express();
const {products,people} = require('./data');
app.use(express.static('./public'));
app.use(express.urlencoded({extended:false}));
app.get('/api/people',(req,res)=>{
    
    res.status(200).json({success:true,data:people});
})
app.post('/api/people', (req, res) => {
    const { name } = req.body
    if (!name) {
      return res
        .status(400)
        .json({ success: false, msg: 'please provide name value' })
    }
    res.status(201).json({ success: true, person: name })
  })
  
app.post('/login',(req,res)=>{
    let {name}=req.body;
    if(name){
        return res.status(200).send(`Welcome ${name}`);
    }
    res.status(401).send('Please enter your credentials');
    
})
app.listen(3000);